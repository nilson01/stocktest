import React from 'react'


export default function AboutUs({ showSidebar }) {



    return (
        <div className='container' onClick={showSidebar}>


        </div>
    )
}

